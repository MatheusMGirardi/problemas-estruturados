
import java.util.ArrayList;

public class pilhaaritmetica {
    Integer topoindex = -1;
    ArrayList<Character> dado = new ArrayList<>();

    public Character topo() {
        if (this.topoindex == -1) {
            return null;
        }
        return this.dado.get(this.topoindex);
    }

    public int vazia() {
        if (this.topoindex == -1) {
            return 1;
        } else {
            return 0;
        }
    }

    public void empilha(char desisto) {
        if (desisto == '{' || desisto == '(' || desisto == '[') {
            this.dado.add(desisto);
            this.topoindex++;
        } else {
            switch (desisto) {
                case '}':
                    if (topo() != null && topo() == '{') {
                        this.desempilha();
                    } else {
                        this.dado.add(desisto);
                        this.topoindex++;
                    }
                    break;
                case ')':
                    if (topo() != null && topo() == '(') {
                        this.desempilha();
                    } else {
                        this.dado.add(desisto);
                        this.topoindex++;
                    }
                    break;
                case ']':
                    if (topo() != null && topo() == '[') {
                        this.desempilha();
                    } else {
                        this.dado.add(desisto);
                        this.topoindex++;
                    }
                    break;
                default:
                    break;
            }
        }
    }

    public void desempilha() {
        if (vazia() == 1) {
            System.out.println("Pilha vazia.");
        } else {
            this.dado.remove(this.topoindex.intValue());
            this.topoindex--;
        }
    }

    public void flush() {
        while (topoindex != -1) {
            desempilha();
        }
    }

    public void check() {
        if (this.vazia() == 1) {
            System.out.println("Expressão boa.");
        } else {
            System.out.println("Expressão ruim.");
        }
    }

    public static void main(String[] args) {
        pilhaaritmetica stack = new pilhaaritmetica();
        String expressaoBoa = "(A + B) + C + { B * [C + B]}";
        String expressaoRuim = "(A + B {D+C}])";
        String expressaoBoa2 = "[A + (B * C)] - {D / E}";
        String expressaoRuim2 = "[A + B) * (C + D]";
        String expressaoBoa3 = "{[A + B] * (C + D)}";
        String expressaoRuim3 = "{A + B * (C + D}";

        String[] expressoes = { expressaoBoa, expressaoRuim, expressaoBoa2, expressaoRuim2, expressaoBoa3,
                expressaoRuim3 };

        for (String expressao : expressoes) {
            for (int i = 0; i < expressao.length(); i++) {
                char c = expressao.charAt(i);
                stack.empilha(c);
            }
            stack.check();
            stack.flush();
        }
    }
}
