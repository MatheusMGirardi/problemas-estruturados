public class NoAVL {
    NoAVL direito;
    NoAVL esquerdo;
    int altura;
    int valor;

    public NoAVL(int valor) {
        this.valor = valor;
    }
}
